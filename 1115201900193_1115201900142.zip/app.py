# ----- CONFIGURE YOUR EDITOR TO USE 4 SPACES PER TAB ----- #
import settings
import sys,os
sys.path.append(os.path.join(os.path.split(os.path.abspath(__file__))[0], 'lib'))
import pymysql as db

def connection():
    ''' User this function to create your connections '''
    con = db.connect(
        settings.mysql_host, 
        settings.mysql_user, 
        settings.mysql_passwd, 
        settings.mysql_schema)

    return con

def mostcommonsymptoms(vax_name):                                   #We didn't do that
    # Create a new connection
    # Create a new connection
    con=connection()
    # Create a cursor on the connection
    cur=con.cursor()

    return [("vax_name","result")]


def buildnewblock(blockfloor):                                       #We didn't do that
    
   # Create a new connection
    con=connection()
    
    # Create a cursor on the connection
    cur=con.cursor()
    
 
    return [("result",),]

def findnurse(x,y):                                                 #Tested X=4 and Υ=4 
                                                                    #Result:  SADIKU MARY	        1053764761	19
                                                                    #         CHANDLER DANA   	    1306943949	10
                                                                    #         RANKIN CHRISTOPHER	1538480975	4
                                                                    #         HAYS WENDY	        1841630910	6

    # Create a new connection
    
    con=connection()
    
    # Create a cursor on the connection
    cur=con.cursor()
    cur=con.cursor()
    #My SQL code
    query="""select nurse.Name , nurse.EmployeeID, count(distinct vaccination.patient_SSN)      
             from nurse, on_call, vaccination, appointment, block
             where nurse.EmployeeID=vaccination.nurse_EmployeeID AND 
                    nurse.EmployeeID=on_call.Nurse AND 
                    nurse.EmployeeID=appointment.PrepNurse  AND 
                    block.BlockFloor=on_call.BlockFloor AND
                    block.BlockFloor='%s' 											 
             group by vaccination.nurse_EmployeeID
             having count(distinct block.BlockCode)=count(distinct on_call.BlockCode) AND
                    count(distinct appointment.Patient)>='%s'""" %(str(x),str(y))
    cur.execute(query)
    result=cur.fetchall()
    #Fixing the format of the table
    l=[["Nurse", "ID", "Number of patients"]]
    for r in result:
        l.append(r)
    return l

def patientreport(patientName):                             #Tested name: VonRueden Samson 
                                                            #Result: VonRueden Samson	DAVIDSON DUSTIN	WHITE KALA	INTERNAL MEDICINE	100.0	2010-04-03 00:44:00	5303	5	3
    # Create a new connection
    con=connection()

    # Create a cursor on the connection
    cur=con.cursor()
    #My SQL code
    query="""select patient.Name,physician.Name, nurse.Name, treatment.Name, treatment.Cost, stay.StayEnd, room.RoomNumber, room.BlockFloor, room.BlockCode 
    from patient, treatment, stay, room, undergoes, physician, nurse
        where patient.SSN=undergoes.Patient AND 
		treatment.Code=undergoes.Treatment AND 
        stay.Patient=patient.SSN AND 
        stay.Room=room.RoomNumber AND 
        undergoes.Stay=stay.StayID AND
        physician.EmployeeID=undergoes.Physician AND
        nurse.EmployeeID=undergoes.AssistingNurse
        AND patient.Name = '%s';""" %(patientName)
    cur.execute(query)
    result=cur.fetchall()
    return [("Patient","Physician", "Nurse", "Date of release", "Treatement going on", "Cost", "Room", "Floor", "Block"),result[0]]
    
