Assignement no.1

Members:
sdi1900193 Aliki Tsamopoulou-Damiani
sdi1900294 Christina Petrisi
sdi1900235 Gerasimos Vallianos


We didn't directly connect the flight with the airport, since that was indirectly done through the airplane company.
Plus in each flight there are the characteristics departure airport and arrival airport. paragraph1

On the entity person we added the characteristic passport number and on the vaccinated person the characteristic passenger(which can only take the values YES or NO). We did that to avoid making an entire new entity passenger. par3

Based on the google definition about the flight manifesto that we found, the manifesto should include the information about the aircraft used, the passengers and the crew. 
We achieved that by connecting the manifesto directly with the aircraft (1-N), with the flight (that connects with booking that includes the vaccinated persons that have the characteristic passenger) and we also assumed that the crew is regarded as a person->vaccinated person->passenger so we didn't have to make a new entity called crew. par3

We created an entity vaccinated person, because not all people can make a booking, only the vaccinated ones. Person!=vaccinated person. par4

We assumed that the specialty of a technician is about what model of aircraft they can work on. 
Because of that we created a table called model has techician to demonstrate that many technicians could work on the same model, aka have the same specialty.  par5

Between the entities technician, air traffic controller and union, we assumed that many of the workers can be members of the same union but not the opposite.
Thus because of the connections that we created, we ended up having the primary keys of the union shared with the other entities instead of the opposite. par5

We assumed that there are two different entities, one being the "type of test" and the other being "testing".
Meaning that there's a set of different types of tests and the entity testing can be either type. par6

We chose to connect the entities aircraft and testing, as well as the testing with the technician. We could have used a 3-way connection but we preferred the other design. par6


