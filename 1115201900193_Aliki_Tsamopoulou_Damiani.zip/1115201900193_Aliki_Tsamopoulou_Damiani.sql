#1
select  patient.SSN, patient.Name, Count(distinct stay.StayID), sum(Cost)
from patient, stay, undergoes, treatment
where patient.SSN=undergoes.Patient AND
		patient.SSN=stay.Patient AND
		stay.StayID=undergoes.Stay AND
		treatment.Code=undergoes.Treatment AND
        patient.age>=30 AND
        patient.age<=40 AND
        patient.Gender="male"
group by patient.SSN
Having  Count(distinct stay.StayID)>1;

#2
select nurse.EmployeeID, nurse.Name
from nurse, on_call, block
where nurse.EmployeeID=on_call.Nurse AND
		block.BlockCode=on_call.BlockCode AND
        block.BlockFloor=on_call.BlockFloor AND
		on_call.OnCallStart >= '2008-04-20 23:22:00' AND
        on_call.OnCallEnd <= '2009-06-04 11:00:00' AND
        block.BlockFloor >= 4 AND block.BlockFloor <= 7
Group by name
Having Count(*)>1;

#3
select patient.SSN, patient.Name
from patient, vaccines, vaccination
where patient.SSN=vaccination.patient_SSN AND
		vaccines.vax_name=vaccination.vaccines_vax_name AND
        patient.Gender="female" AND
        patient.Age > 40 
Group by name, num_of_doses
Having Count(vaccination.vaccination_date)=vaccines.num_of_doses;

#4
select distinct medication.Name, medication.Brand, count(*)
from medication, prescribes
where prescribes.Medication=medication.Code
group by prescribes.Medication
having count(*)>1;

#5
/*I couldn't figure out how to solve this*/


#6
select "yes" AS Result where exists(
select distinct stay.Room
from stay
where (stay.StayStart>='2013-01-01 00:00:00' AND stay.StayStart<='2013-12-12 23:59:59') OR 
			(stay.StayEnd>='2013-01-01 00:00:00' AND stay.StayEnd<='2013-12-12 23:59:59'))
UNION
select "no" AS Result where not exists(
select distinct stay.Room
from stay
where (stay.StayStart>='2013-01-01 00:00:00' AND stay.StayStart<='2013-12-12 23:59:59') OR 
			(stay.StayEnd>='2013-01-01 00:00:00' AND stay.StayEnd<='2013-12-12 23:59:59'));


#7
select distinct physician.EmployeeID, physician.Name, count(distinct undergoes.Patient)
from physician, undergoes
where physician.EmployeeID=undergoes.Physician AND
        physician.Position="PATHOLOGY"
group by physician.EmployeeID
UNION
select distinct physician.EmployeeID, physician.Name, 0
from physician
where physician.Position="PATHOLOGY" AND not exists(
select * 
from undergoes
where undergoes.Physician=physician.EmployeeID);



#8
select patient.Name
from patient, vaccines, vaccination
where patient.SSN=vaccination.patient_SSN AND
		vaccines.vax_name=vaccination.vaccines_vax_name
Group by patient.Name, vaccines.num_of_doses
Having Count(vaccination.vaccination_date) != vaccines.num_of_doses
UNION
select patient.Name
from patient
where not exists (select vaccination.patient_SSN
from vaccination
where patient.SSN=vaccination.patient_SSN);


#9
/*I couldn't figure out how to show only Sputnik without using CREATE which is not allowed*/
select vaccination.vaccines_vax_name, count(*)  
from vaccination
group by vaccination.vaccines_vax_name
having count(*)>= ALL (select count(*)
						from vaccines
                        where vaccination.vaccines_vax_name=vaccines.vax_name
                        group by vaccination.vaccines_vax_name);



#10
select distinct physician.Name
from physician,trained_in,treatment
where physician.EmployeeID=trained_in.Physician AND
		treatment.Code= trained_in.Speciality AND
		treatment.Name= "RADIATION ONCOLOGY";
        
        
        
        
        
